# -*- coding: utf-8 -*-

import json
import re
import os
import torch
import numpy as np
from torch.utils.data import Dataset, DataLoader
from transformers import BertTokenizer
"""
数据加载
"""

class DataGenerator:
    def __init__(self, data_path, config):
        self.config = config
        self.path = data_path
        # self.label_to_id = config["label_to_id"]
        self.schema = self.load_schema(config["schema_path"])
        self.config["num_labels"] = len(self.schema)
        if self.config["model_type"] == "bert":
            self.tokenizer = BertTokenizer.from_pretrained(config["pretrain_model_path"])
        self.load()

        # self.index_to_label = 
        # self.label_to_index = dict((y, x) for x, y in self.index_to_label.items())
        # self.config["class_num"] = len(self.index_to_label)
        # if self.config["model_type"] == "bert":
        #     self.tokenizer = BertTokenizer.from_pretrained(config["pretrain_model_path"])
        # self.vocab = load_vocab(config["vocab_path"])
        # self.config["vocab_size"] = len(self.vocab)
        # self.load()

    def load(self):
        self.data = []
        with open(self.path, encoding="utf8") as f:
            segments = f.read().split("\n\n")
            # print("segments = ",segments)
            for segment in segments:
                # print("segment = ",segment)
                sentenece = []
                labels = []
                for line in segment.split("\n"):
                    if line.strip() == "":
                        continue
                    char, label = line.split()
                    # print("char = ",char)
                    # print("label = ",label)
                    sentenece.append(char)
                    id = self.schema[label]
                    if id not in range(0,self.config["num_labels"]):  # 不在0-num_labels范围内，则替换为 PAD 的 ID
                        id = self.schema["PAD"]
                    labels.append(self.schema[label])
                # print("sentenece = ",sentenece)
                # print("labels = ",labels)

                # self.sentences.append("".join(sentenece))
                if self.config["model_type"] == "bert":
                    input_dict = self.tokenizer.encode_plus(
                        sentenece,
                        max_length=self.config["max_length"],
                        padding="max_length",
                        truncation=True,
                        return_attention_mask=True,
                        return_tensors="pt"
                    )
                else:
                    input_dict = self.encode_sentence(sentenece)
                # print("torch.LongTensor(labels) = ",torch.LongTensor(labels))
                # print("input_ids = ",input_ids)
                input_dict["input_ids"] = input_dict["input_ids"].squeeze(0)
                input_dict["attention_mask"] = input_dict["attention_mask"].squeeze(0)
                input_dict["token_type_ids"] = input_dict["token_type_ids"].squeeze(0)

                labels = self.padding(labels, self.schema["PAD"])
                #label_ids
                self.data.append((input_dict, torch.LongTensor(labels)))

#************************************************************
        # with open(self.path, encoding="utf8") as f:
        #     for line in f:
        #         line = json.loads(line)
        #         text = line["text"]
        #         labels = line["labels"]  # 假设数据格式为：{"text": "文本内容", "labels": ["O", "B-PER", "I-PER", ...]}
        #         if self.config["model_type"] == "bert":
        #             inputs = self.tokenizer.encode_plus(
        #                 text,
        #                 max_length=self.config["max_length"],
        #                 padding="max_length",
        #                 truncation=True,
        #                 return_attention_mask=True,
        #                 return_tensors="pt"
        #             )
        #             label_ids = [self.label_to_id[label] for label in labels]
        #             label_ids += [self.label_to_id["PAD"]] * (self.config["max_length"] - len(labels))
        #             label_ids = torch.LongTensor(label_ids)
        #         else:
        #             inputs = self.encode_sentence(text)
        #         self.data.append((inputs, label_ids))               

        return

    def encode_sentence(self, text):
        input_id = []
        for char in text:
            input_id.append(self.vocab.get(char, self.vocab["[UNK]"]))
        input_id = self.padding(input_id)
        return input_id

    #补齐或截断输入的序列，使其可以在一个batch内运算
    def padding(self, input_id, pad_token=0):
        input_id = input_id[:self.config["max_length"]]
        input_id += [pad_token] * (self.config["max_length"] - len(input_id))
        return input_id

    def load_schema(self, path):
        with open(path, encoding="utf8") as f:
            return json.load(f)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, index):
        return self.data[index]

def load_vocab(vocab_path):
    token_dict = {}
    with open(vocab_path, encoding="utf8") as f:
        for index, line in enumerate(f):
            token = line.strip()
            token_dict[token] = index + 1  #0留给padding位置，所以从1开始
    return token_dict


#用torch自带的DataLoader类封装数据
def load_data(data_path, config, shuffle=True):
    dg = DataGenerator(data_path, config)
    dl = DataLoader(dg, batch_size=config["batch_size"], shuffle=shuffle)
    return dl

if __name__ == "__main__":
    from config import Config
    # dg = DataGenerator("valid_tag_news.json", Config)
    dg = DataGenerator(Config["train_data_path"], Config)
    # print(dg[1])
