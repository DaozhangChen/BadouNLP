# -*- coding: utf-8 -*-

"""
配置参数信息
"""

Config = {
    "model_path": "output",
    "train_data_path": "ner_data/train",
    "valid_data_path": "ner_data/test",
    "schema_path": "ner_data/schema.json",
    "vocab_path":"chars.txt",
    "model_type":"bert",
    "max_length": 20,
    "hidden_size": 128,
    "kernel_size": 3,
    "num_layers": 2,
    "epoch": 10,
    "batch_size": 64,
    # "batch_size": 1920,
    "tuning_tactics":"lora_tuning",
    # "tuning_tactics":"p_tuning",
    # "tuning_tactics":"finetuing",
    "pooling_style":"max",
    "optimizer": "adam",
    "learning_rate": 1e-3,
    "use_crf": False,
    "class_num": 9,
    "pretrain_model_path":r"E:\AIClass\八斗AI课\week6_语言模型和预训练\bert-base-chinese",
    "seed": 987,
    "num_labels": 10, #changed in loader.py DataGenerator;  
    # "num_labels" is equal to "class_num"
    # "label_to_id": {
    # "B-LOCATION": 0,
    # "B-ORGANIZATION": 1,
    # "B-PERSON": 2,
    # "B-TIME": 3,
    # "I-LOCATION": 4,
    # "I-ORGANIZATION": 5,
    # "I-PERSON": 6,
    # "I-TIME": 7,
    # "O": 8,
    # "PAD":9
    # }
}