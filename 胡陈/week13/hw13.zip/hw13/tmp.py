



# tuning_tactics = Config["tuning_tactics"]

# print("正在使用 %s"%tuning_tactics)

# if tuning_tactics == "lora_tuning":
#     peft_config = LoraConfig(
#         r=8,
#         lora_alpha=32,
#         lora_dropout=0.1,
#         target_modules=["query", "key", "value"]
#     )
# elif tuning_tactics == "p_tuning":
#     peft_config = PromptEncoderConfig(task_type="SEQ_CLS", num_virtual_tokens=10)
# elif tuning_tactics == "prompt_tuning":
#     peft_config = PromptTuningConfig(task_type="SEQ_CLS", num_virtual_tokens=10)
# elif tuning_tactics == "prefix_tuning":
#     peft_config = PrefixTuningConfig(task_type="SEQ_CLS", num_virtual_tokens=10)

# #重建模型
# model = TorchModel
# # print(model.state_dict().keys())
# # print("====================")

# model = get_peft_model(model, peft_config)
# # print(model.state_dict().keys())
# # print("====================")

# state_dict = model.state_dict()

# #将微调部分权重加载
# if tuning_tactics == "lora_tuning":
#     loaded_weight = torch.load('output/lora_tuning.pth')
# elif tuning_tactics == "p_tuning":
#     loaded_weight = torch.load('output/p_tuning.pth')
# elif tuning_tactics == "prompt_tuning":
#     loaded_weight = torch.load('output/prompt_tuning.pth')
# elif tuning_tactics == "prefix_tuning":
#     loaded_weight = torch.load('output/prefix_tuning.pth')

# print(loaded_weight.keys())
# state_dict.update(loaded_weight)

# #权重更新后重新加载到模型
# model.load_state_dict(state_dict)

# #进行一次测试
# cuda_flag = torch.cuda.is_available()
# if cuda_flag:
#     logger.info("gpu可以使用，迁移模型至gpu")
#     model = model.cuda()
    
# evaluator = Evaluator(Config, model, logger)
# evaluator.eval(0)




# if __name__ == "__main__":
#     model = TorchModel
#     model = get_peft_model(model, peft_config)
#     state_dict = torch.load("output/lora_tuning.pth")
#     model.load_state_dict(state_dict)
#     model = model.cuda()

#     evaluator = Evaluator(Config, model, logger)
#     evaluator.eval(0)




# # main.py
# import torch
# import os
# import random
# import os
# import numpy as np
# import torch.nn as nn
# import logging
# from config import Config
# from model import TorchModel, choose_optimizer
# from evaluate import Evaluator
# from loader import load_data
# from peft import get_peft_model, LoraConfig, \
#     PromptTuningConfig, PrefixTuningConfig, PromptEncoderConfig 
# from transformers import get_linear_schedule_with_warmup


# def main(config):
#     if not os.path.isdir(config["model_path"]):
#         os.mkdir(config["model_path"])
#     train_data = load_data(config["train_data_path"], config)
#     model = TorchModel

#     tuning_tactics = config["tuning_tactics"]
#     if tuning_tactics == "lora_tuning":
#         peft_config = LoraConfig(
#             r=8,
#             lora_alpha=32,
#             lora_dropout=0.1,
#             target_modules=["query", "key", "value"]
#         )
#     model = get_peft_model(model, peft_config)

#     if torch.cuda.is_available():
#         model = model.cuda()

#     optimizer = choose_optimizer(config, model)
#     scheduler = get_linear_schedule_with_warmup(optimizer, num_warmup_steps=0, num_training_steps=len(train_data) * config["epoch"])

#     evaluator = Evaluator(config, model, logger)

#     for epoch in range(config["epoch"]):
#         model.train()
#         logger.info("Epoch %d begin" % epoch)
#         for index, batch_data in enumerate(train_data):
#             if torch.cuda.is_available():
#                 batch_data = [d.cuda() for d in batch_data]
#             input_ids, labels = batch_data
#             optimizer.zero_grad()
#             outputs = model(input_ids, labels=labels)
#             loss = outputs.loss
#             loss.backward()
#             optimizer.step()
#             scheduler.step()
#             if index % int(len(train_data) / 2) == 0:
#                 logger.info("Batch loss: %.4f" % loss.item())
#         evaluator.eval(epoch)
#     model_path = os.path.join(config["model_path"], "%s.pth" % tuning_tactics)
#     save_tunable_parameters(model, model_path)


# def save_tunable_parameters(model, path):
#     saved_params = {
#         k: v.to("cpu")
#         for k, v in model.named_parameters()
#         if v.requires_grad
#     }
#     torch.save(saved_params, path)