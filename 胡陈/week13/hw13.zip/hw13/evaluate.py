# -*- coding: utf-8 -*-
import torch
import json
from loader import load_data
from seqeval.metrics import f1_score, precision_score, recall_score
"""
模型效果测试
"""

class Evaluator:
    def __init__(self, config, model, logger):
        self.config = config
        self.model = model
        self.logger = logger
        self.valid_data = load_data(config["valid_data_path"], config, shuffle=False)
        self.stats_dict = {"correct":0, "wrong":0}  #用于存储测试结果
        self.schema = self.load_schema(config["schema_path"])
        self.id_to_label = {v: k for k, v in self.schema.items()}

    def eval(self, epoch):
        self.logger.info("开始测试第%d轮模型效果：" % (epoch+1))
        self.model.eval()
        true_labels = []
        pred_labels = []

        for index, batch_data in enumerate(self.valid_data):
            # no cuda
            input_dict, labels = batch_data
            input_ids = input_dict["input_ids"]
            attention_mask = input_dict["attention_mask"]
            token_type_ids = input_dict["token_type_ids"]

            with torch.no_grad():
                pred_results = self.model(input_ids=input_ids, attention_mask=attention_mask, token_type_ids=token_type_ids)
                logits = pred_results.logits
                predictions = torch.argmax(logits, dim=-1)

            # self.write_stats(labels, pred_results)
            true_labels.extend([[self.id_to_label[label.item()] for label in label_list] for label_list in labels])
            pred_labels.extend([[self.id_to_label[pred.item()] for pred in pred_list] for pred_list in predictions])

        self.show_stats(true_labels, pred_labels)

    def show_stats(self, true_labels, pred_labels):
        precision = precision_score(true_labels, pred_labels)
        recall = recall_score(true_labels, pred_labels)
        f1 = f1_score(true_labels, pred_labels)
        self.logger.info("Precision: %.4f, Recall: %.4f, F1: %.4f" % (precision, recall, f1))


#************************************************************

        # self.stats_dict = {"correct": 0, "wrong": 0}  # 清空上一轮结果
        # for index, batch_data in enumerate(self.valid_data):
        #     if torch.cuda.is_available():
        #         batch_data = [d.cuda() for d in batch_data]
        #     input_ids, labels = batch_data   #输入变化时这里需要修改，比如多输入，多输出的情况
        #     with torch.no_grad():
        #         pred_results = self.model(input_ids)[0]
        #     self.write_stats(labels, pred_results)
        # acc = self.show_stats()
        # return acc

    # def write_stats(self, labels, pred_results):
    #     logits = pred_results.logits
    #     # assert len(labels) == len(pred_results)
    #     for true_label, pred_label in zip(labels, pred_results):
    #         pred_label = torch.argmax(pred_label, dim=-1)
    #         # print(true_label, pred_label)
    #         if int(true_label) == int(pred_label):
    #             self.stats_dict["correct"] += 1
    #         else:
    #             self.stats_dict["wrong"] += 1
    #     return

    # def show_stats(self):
    #     correct = self.stats_dict["correct"]
    #     wrong = self.stats_dict["wrong"]
    #     self.logger.info("预测集合条目总量：%d" % (correct +wrong))
    #     self.logger.info("预测正确条目：%d，预测错误条目：%d" % (correct, wrong))
    #     self.logger.info("预测准确率：%f" % (correct / (correct + wrong)))
    #     self.logger.info("--------------------")
    #     return correct / (correct + wrong)
    
    def load_schema(self, path):
        with open(path, encoding="utf8") as f:
            return json.load(f)
